package LWP::DebugFile;

our $VERSION = '6.47';

# legacy stub

1;
