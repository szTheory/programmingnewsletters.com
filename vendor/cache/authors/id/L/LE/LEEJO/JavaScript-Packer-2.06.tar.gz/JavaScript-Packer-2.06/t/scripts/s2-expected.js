function(c){var a='blah blubb';var e=3;alert(a);var d=1;//@a
var b=c;/*@abcd var d=1;@*/abcd var f=$H()};/*@abcd var x=1;@*/