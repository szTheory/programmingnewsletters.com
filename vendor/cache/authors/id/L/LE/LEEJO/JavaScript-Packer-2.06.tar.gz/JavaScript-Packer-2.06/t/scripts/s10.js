function initScript() {
    var config = parseXML("config.xml").getElementsByTagName("config");

    var konfig = parseXML('konfig.xml').getElementsByTagName('konfig');

    var conf_xml = 'conf.xml';
    var conf = 'conf';

    var konf = parseXML(conf_xml).getElementsByTagName(conf);
}