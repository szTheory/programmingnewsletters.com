function ( hmpf ) {
	var argh = 'blah blubb';
	var y = 3;
	alert( argh );
	var x = 1;//@a  
	var b = hmpf;/*@ abcd
var x = 1;@*/ abcd
/*a*/  
/*
blah
*/
	var z = $H();  // comment
};
// another comment
